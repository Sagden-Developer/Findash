let next = document.getElementById('next')
let previous = document.getElementById('previous')
let navs = document.querySelector('.navigations')
let space = 40

next.addEventListener('click',()=>{
    navs.style.transform += `translateX(${space}px)`
})
previous.addEventListener('click',()=>{
    navs.style.transform += `translateX(-${space}px)`
})